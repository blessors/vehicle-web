import os

from flask import Flask
from flask_cors import CORS

from config.config import Config
from web.config.socket_set import socketio
from web.routes import register_routes

app = Flask(__name__)
CORS(app)  # 启用跨域请求支持

register_routes(app)

socketio.init_app(app, cors_allowed_origins="*", async_mode='threading')

config = Config()

# 确保上传文件夹存在
os.makedirs(config.UPLOAD_FOLDER, exist_ok=True)
os.makedirs(config.PROCESSED_FOLDER, exist_ok=True)
os.makedirs(config.TEMP_FOLDER, exist_ok=True)


if __name__ == '__main__':
    #app.run(host='127.0.0.1', port=5000, debug=False)
    socketio.run(app, debug=True, host='127.0.0.1', port=5000, allow_unsafe_werkzeug=True)
