from .detect_video import video_bp
from .detect_pic import pic_bp

def register_routes(app):
    app.register_blueprint(video_bp)
    app.register_blueprint(pic_bp)