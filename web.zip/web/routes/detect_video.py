from flask import request, jsonify, send_file, Blueprint
import os
import json
import threading
from werkzeug.utils import secure_filename
from datetime import datetime

from web.config.config import Config
from web.utils.file_rec import res_code
from web.utils.video_frame import process_video

config = Config()
logger = config.logger

video_bp = Blueprint('video', __name__)

# 验证文件扩展名
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in config.ALLOWED_EXTENSIONS


# 路由定义
@video_bp.route('/detect/video/check_file/<file_id>', methods=['GET'])
def check_file(file_id):
    """检查文件是否已存在（已处理过）"""
    processed_path = os.path.join(config.PROCESSED_FOLDER, f"{file_id}.mp4")

    if os.path.exists(processed_path):
        # 构建文件访问URL
        video_url = f"/detect/video/processed_videos/{file_id}.mp4"
        return jsonify({
            'exists': True,
            'url': video_url
        })

    return jsonify({'exists': False})


@video_bp.route('/detect/video/init_upload', methods=['POST'])
def init_upload():
    """初始化上传任务"""
    try:
        data = request.json
        file_id = data.get('file_id')
        file_name = data.get('file_name')
        file_size = data.get('file_size')
        total_chunks = data.get('total_chunks')
        #print(data)

        if not all([file_id, file_name, file_size, total_chunks]):
            return jsonify({'success': False, 'message': '缺少必要参数'})

        # 创建此文件的上传目录
        file_upload_dir = os.path.join(config.TEMP_FOLDER, file_id)
        os.makedirs(file_upload_dir, exist_ok=True)

        # 记录上传任务信息
        task_info = {
            'file_id': file_id,
            'file_name': secure_filename(file_name),
            'file_size': file_size,
            'total_chunks': total_chunks,
            'received_chunks': 0,
            'upload_started': datetime.now().isoformat(),
            'status': 'initialized'
        }

        # 保存任务信息到文件
        with open(os.path.join(file_upload_dir, 'info.json'), 'w') as f:
            json.dump(task_info, f)

        return jsonify(res_code(200,{'message': '上传任务初始化成功', 'file_id': file_id }))

    except Exception as e:
        logger.error(f"初始化上传时出错: {str(e)}")
        return jsonify(res_code(400, {'message': f"初始化上传失败: {str(e)}"}))


@video_bp.route('/detect/video/upload_chunk', methods=['POST'])
def upload_chunk():
    """上传文件分片"""
    try:
        file_id = request.form.get('file_id')
        chunk_index = int(request.form.get('chunk_index'))
        file_chunk = request.files.get('file')


        if not all([file_id, chunk_index is not None, file_chunk]):
            return jsonify({'success': False, 'message': '缺少必要参数'})

        # 检查上传目录
        file_upload_dir = os.path.join(config.TEMP_FOLDER, file_id)
        if not os.path.exists(file_upload_dir):
            return jsonify({'success': False, 'message': '上传任务不存在'})

        # 保存分片
        chunk_path = os.path.join(file_upload_dir, f"chunk_{chunk_index}")
        file_chunk.save(chunk_path)

        # 更新任务信息
        info_path = os.path.join(file_upload_dir, 'info.json')
        with open(info_path, 'r') as f:
            task_info = json.load(f)

        task_info['received_chunks'] += 1

        with open(info_path, 'w') as f:
            json.dump(task_info, f)

        return jsonify(res_code(200,
            {'message': f'分片 {chunk_index} 上传成功',
                'received_chunks': task_info['received_chunks'],
                'total_chunks': task_info['total_chunks']}))

    except Exception as e:
        logger.error(f"上传分片时出错: {str(e)}")
        return jsonify(res_code(400,{'message': f"分片上传失败: {str(e)}"}))


@video_bp.route('/detect/video/complete_upload', methods=['POST'])
def complete_upload():
    """完成上传，合并分片并开始处理视频"""
    try:
        data = request.json
        file_id = data.get('file_id')
        file_name = data.get('file_name')

        if not all([file_id, file_name]):
            return jsonify({'success': False, 'message': '缺少必要参数'})

        # 检查上传目录
        file_upload_dir = os.path.join(config.TEMP_FOLDER, file_id)
        if not os.path.exists(file_upload_dir):
            return jsonify({'success': False, 'message': '上传任务不存在'})

        # 读取任务信息
        info_path = os.path.join(file_upload_dir, 'info.json')
        with open(info_path, 'r') as f:
            task_info = json.load(f)

        # 检查所有分片是否都已上传
        if task_info['received_chunks'] != task_info['total_chunks']:
            return jsonify(res_code(400, {'message': f"分片不完整: 已接收 {task_info['received_chunks']}/{task_info['total_chunks']}"}))

        # 创建合并后的文件
        file_ext = os.path.splitext(file_name)[1].lower()
        if not file_ext:
            file_ext = '.mp4'  # 默认扩展名

        merged_filename = secure_filename(f"{file_name}_{file_id}{file_ext}")
        merged_path = os.path.join(config.UPLOAD_FOLDER, merged_filename)

        # 合并分片
        with open(merged_path, 'wb') as merged_file:
            for i in range(task_info['total_chunks']):
                chunk_path = os.path.join(file_upload_dir, f"chunk_{i}")
                with open(chunk_path, 'rb') as chunk_file:
                    merged_file.write(chunk_file.read())

        # 更新任务状态
        task_info['status'] = 'uploaded'
        task_info['upload_completed'] = datetime.now().isoformat()
        task_info['merged_path'] = merged_path

        with open(info_path, 'w') as f:
            json.dump(task_info, f)

        # 启动视频处理线程
        processing_thread = threading.Thread(
            target=process_video,
            args=(file_id, merged_path, task_info)
        )
        processing_thread.daemon = True
        processing_thread.start()

        # 清理分片目录
        for i in range(task_info['total_chunks']):
            chunk_path = os.path.join(file_upload_dir, f"chunk_{i}")
            if os.path.exists(chunk_path):
                os.remove(chunk_path)

        return jsonify(res_code(200, {'message': '文件上传完成，开始处理', 'file_id': file_id}))

    except Exception as e:
        logger.error(f"完成上传时出错: {str(e)}")
        return jsonify(res_code(400, {'message': f"完成上传失败: {str(e)}"}))


@video_bp.route('/detect/video/processed_videos/<filename>', methods=['GET'])
def get_processed_video(filename):
    """获取处理后的视频文件"""
    file_path = os.path.join(config.PROCESSED_FOLDER, filename)
    if os.path.exists(file_path):
        return send_file(file_path, mimetype='video/mp4')
    return jsonify({'success': False, 'message': '文件不存在'}), 404


@video_bp.route('/detect/video/get_video/<file_id>', methods=['GET'])
def get_video(file_id):
    """获取视频文件的URL"""
    video_path = os.path.join(config.PROCESSED_FOLDER, f"{file_id}.mp4")
    if os.path.exists(video_path):
        return jsonify({
            'success': True,
            'video_url': f"/detect/video/processed_videos/{file_id}.mp4"
        })
    return jsonify({'success': False, 'message': '视频尚未处理完成'}), 404




