import io
import os
import uuid
import zipfile
from datetime import datetime

from flask import Blueprint, request, jsonify
from web.utils.file_rec import detect, res_code
from web.utils.upload_css import upload_to_oss

pic_bp = Blueprint('pic', __name__)

@pic_bp.route('/detect/picture', methods=['POST'])
def detect_pic():
    if 'file' not in request.files:
        return jsonify({'error': 'No image provided'}), 400

    # 获取上传的图像
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    try:
        img_bytes, proc_time = detect(file)
        # 生成唯一ID和文件名
        file_id = str(uuid.uuid4())
        original_filename = file.filename
        file_extension = os.path.splitext(original_filename)[1]
        new_filename = f"detect/picture/{file_id}{file_extension}"  # 存储在detected目录下

        # 上传到阿里云OSS
        oss_url = upload_to_oss(img_bytes, new_filename)

        # 获取当前时间
        upload_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

        # 构建响应数据
        response_data = {
            'url': oss_url,
            'name': original_filename,
            'id': file_id,
            'uploadTime': upload_time,
            'processingTime': f"{proc_time:.2f} seconds",
            'status': 'success'
        }

        return jsonify(res_code(200, response_data))

    except Exception as e:
        return jsonify({'error': str(e), 'status': 'failed'}), 500

@pic_bp.route('/detect/zip', methods=['POST'])
def detect_pics():
    if 'file' not in request.files:
        return jsonify({'error': 'No zip file provided'}), 400

    # 获取上传的zip文件
    file = request.files['file']
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400

    if not file.filename.lower().endswith('.zip'):
        return jsonify({'error': 'File is not a ZIP archive'}), 400

    try:
        # 读取zip文件内容
        zip_data = io.BytesIO(file.read())

        # 存储所有处理结果
        results = []

        with zipfile.ZipFile(zip_data, 'r') as zip_ref:
            # 获取zip中所有文件列表
            file_list = zip_ref.namelist()
            file_list_id = str(uuid.uuid4())
            for filename in file_list:
                # 检查是否是图片文件（简单扩展名检查）
                if not filename.lower().endswith(('.png', '.jpg', '.jpeg', '.bmp', '.gif')):
                    continue

                try:
                    # 读取图片文件
                    with zip_ref.open(filename) as img_file:
                        img_bytes, proc_time = detect(img_file)

                        # 生成唯一ID和文件名
                        file_id = str(uuid.uuid4())
                        original_filename = os.path.basename(filename)
                        file_extension = os.path.splitext(original_filename)[1]
                        new_filename = f"detect/zip/{file_list_id}/{file_id}{file_extension}"

                        # 上传到阿里云OSS
                        oss_url = upload_to_oss(img_bytes, new_filename)

                        # 获取当前时间
                        upload_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')

                        # 添加到结果列表
                        results.append({
                            'url': oss_url,
                            'name': original_filename,
                            'id': file_id,
                            'uploadTime': upload_time,
                            'processingTime': f"{proc_time:.2f} seconds",
                            'status': 'success'
                        })

                except Exception as e:
                    # 记录处理失败的图片信息
                    results.append({
                        'name': os.path.basename(filename),
                        'status': 'failed',
                        'error': str(e)
                    })
                    continue

        # 检查是否有成功处理的图片
        if not results:
            return jsonify({'error': 'No valid images found in ZIP file'}), 400
        print(results)
        return jsonify(res_code(200, {
          'images': results
        }))

    except Exception as e:
        return jsonify({'error': str(e), 'status': 'failed'}), 500