# 阿里云OSS配置
import logging
import os

import oss2

class Config:


    # 初始化OSS客户端
    auth = oss2.Auth(OSS_ACCESS_KEY_ID, OSS_ACCESS_KEY_SECRET)
    bucket = oss2.Bucket(auth, OSS_ENDPOINT, OSS_BUCKET_NAME)

    UPLOAD_FOLDER = 'uploads'
    PROCESSED_FOLDER = 'processed'
    TEMP_FOLDER =  'temp'

    ALLOWED_EXTENSIONS = {'mp4', 'avi', 'mov', 'wmv', 'mkv'}
    MAX_CONTENT_LENGTH = 8 * 1024 * 1024 * 1024  # 8GB

    # 线程池配置
    THREAD_POOL_MAX_WORKERS = os.environ.get('THREAD_POOL_MAX_WORKERS') or 8

    # 配置日志
    logging.basicConfig(level=logging.INFO,
                        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    logger = logging.getLogger(__name__)



