from web.utils.video_merge_audio import video_merge_audio

video_merge_audio('../processed/test_1.mp4', '../processed/test_2.mp4')