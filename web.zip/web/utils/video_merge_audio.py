from moviepy import VideoFileClip


def video_merge_audio(processed_video_path, original_video_path):
    # 定义一个新的输出路径
    output_path = processed_video_path.replace('.mp4', '_with_audio.mp4')

    # 读取处理后的视频
    processed_video = VideoFileClip(processed_video_path)

    # 从原始视频中提取音频
    original_video = VideoFileClip(original_video_path)

    # 将原始音频添加到处理后的视频中
    if original_video.audio:
        processed_video.audio = original_video.audio

        # 写入最终视频文件
        processed_video.write_videofile(output_path, codec='libx264', audio_codec='aac', fps=processed_video.fps)
    else:
        # 如果没有音频，只需将处理后的视频写入
        processed_video.write_videofile(output_path, codec='libx264')

    # 清理资源
    processed_video.close()
    original_video.close()

    return output_path