
import concurrent
import os
import shutil
import threading
import time
from queue import Queue, Empty

import cv2

from web.config.config import Config
from web.utils import socketio_frame
from web.utils.file_rec import detect_frame
from web.utils.upload_css import upload_to_oss
from web.utils.video_merge_audio import video_merge_audio

config = Config()
logger = config.logger


# 视频处理函数
def process_video(file_id, video_path, task_info):
    """
    处理视频文件

    参数:
    - file_id: 文件唯一标识符
    - video_path: 视频文件路径
    - task_info: 任务信息
    """
    try:
        # 打开视频文件
        cap = cv2.VideoCapture(video_path)
        if not cap.isOpened():
            raise Exception("无法打开视频文件")

        # 获取视频属性
        frame_count = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))
        fps = cap.get(cv2.CAP_PROP_FPS)
        width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
        height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))

        # 创建任务状态
        task_state = {
            'file_id': file_id,
            'total_frames': frame_count,
            'processed_frames': 0,
            'start_time': time.time(),
            'status': 'processing',
            'should_stop': False,
            'output_path': os.path.join(config.PROCESSED_FOLDER, f"{file_id}.mp4")
        }

        socketio_frame.active_tasks[file_id] = task_state

        # 创建输出视频写入器
        fourcc = cv2.VideoWriter_fourcc(*'avc1')
        temp_output_path = os.path.join(config.TEMP_FOLDER, f"{file_id}_temp.mp4")
        out = cv2.VideoWriter(temp_output_path, fourcc, fps, (width, height))

        # 创建帧缓冲队列
        frame_queue = Queue()
        processed_frame_queue = Queue()
        socketio_frame.frame_buffers[file_id] = processed_frame_queue

        # 创建线程池
        with concurrent.futures.ThreadPoolExecutor(max_workers=config.THREAD_POOL_MAX_WORKERS) as executor:
            # 启动帧处理线程
            future_to_frame = {}

            # 先读取一部分帧来初始化缓冲
            initial_buffer_size = min(30, frame_count)  # 初始缓冲30帧或全部帧
            for _ in range(initial_buffer_size):
                ret, frame = cap.read()
                if not ret:
                    break
                frame_queue.put((frame, _))

            # 持续将帧添加到队列
            def frame_producer():
                frame_idx = initial_buffer_size
                while frame_idx < frame_count:
                    if task_state['should_stop']:
                        break

                    ret, frame = cap.read()
                    if not ret:
                        break

                    frame_queue.put((frame, frame_idx))
                    frame_idx += 1

                # 标记队列结束
                frame_queue.put((None, -1))

            # 启动生产者线程
            producer_thread = threading.Thread(target=frame_producer)
            producer_thread.daemon = True
            producer_thread.start()

            # 处理帧函数
            def process_frame_task(frame_data):
                if task_state['should_stop']:
                    return None, -1

                frame, frame_idx = frame_data
                if frame is None:
                    return None, -1

                # 在这里调用帧处理逻辑
                processed_frame = process_frame(frame)

                return processed_frame, frame_idx

            # 消费者：提交帧处理任务给线程池
            while True:
                if task_state['should_stop']:
                    break

                try:
                    frame_data = frame_queue.get(timeout=1)
                    frame, frame_idx = frame_data

                    if frame is None:
                        break

                    # 提交给线程池处理
                    future = executor.submit(process_frame_task, frame_data)
                    future_to_frame[future] = frame_idx

                except Empty:
                    continue
                except Exception as e:
                    logger.error(f"处理帧 {frame_idx} 时出错: {str(e)}")
                    continue

            # 处理完成的帧
            completed_frames = 0
            next_frame_to_write = 0
            frames_buffer = {}

            # 等待并处理完成的帧
            for future in concurrent.futures.as_completed(future_to_frame):
                if task_state['should_stop']:
                    break

                try:
                    processed_frame, frame_idx = future.result()
                    if processed_frame is None:
                        continue

                    # 存储帧以确保按顺序写入
                    frames_buffer[frame_idx] = processed_frame

                    # 按顺序写入帧
                    while next_frame_to_write in frames_buffer:
                        current_frame = frames_buffer.pop(next_frame_to_write)
                        out.write(current_frame)

                        # 将处理后的帧发送到前端
                        socketio_frame.send_processed_frame(file_id, current_frame)

                        next_frame_to_write += 1
                        completed_frames += 1

                        # 更新处理进度
                        elapsed_time = time.time() - task_state['start_time']
                        frames_per_second = completed_frames / elapsed_time if elapsed_time > 0 else 0
                        remaining_frames = frame_count - completed_frames
                        estimated_time_remaining = remaining_frames / frames_per_second if frames_per_second > 0 else 0

                        # 计算进度百分比
                        progress_percent = (completed_frames / frame_count) * 100
                        #print("已发送处理进度")
                        # 每处理10帧或进度变化超过1%时发送更新
                        if completed_frames % 10 == 0 or completed_frames == frame_count:
                            socketio_frame.send_progress_update(file_id, {
                                'processed_frames': completed_frames,
                                'total_frames': frame_count,
                                'progress_percent': progress_percent,
                                'estimated_time_remaining': int(estimated_time_remaining)
                            })

                except Exception as e:
                    logger.error(f"处理帧结果时出错: {str(e)}")
                    continue

            # 释放资源
            cap.release()
            out.release()

            # 将处理后的视频移动到最终位置
            if os.path.exists(temp_output_path):
                final_output_path = task_state['output_path']
                shutil.move(temp_output_path, final_output_path)
                final_output_path = video_merge_audio(final_output_path, video_path)
                # 上传到OSS
                try:
                    with open(final_output_path, 'rb') as f:
                        file_data = f.read()
                        oss_path = upload_to_oss(file_data, f"detect/video/{file_id}.mp4")

                        # 发送完成通知
                        socketio_frame.send_completion_notification(file_id, {
                            'video_url': oss_path,
                            'file_name': task_info['file_name']
                            #'video_url': f"/detect/video/processed_videos/{file_id}.mp4"
                        })
                        print("oss_path : " + oss_path)
                except Exception as e:
                    logger.error(f"上传到OSS时出错: {str(e)}")

                    # 即使OSS上传失败，仍然通知前端处理完成
                    socketio_frame.send_completion_notification(file_id, {
                        'video_url': f"/detect/video/processed_videos/{file_id}.mp4"
                    })

            # 清理
            if file_id in socketio_frame.active_tasks:
                del socketio_frame.active_tasks[file_id]
            if file_id in socketio_frame.frame_buffers:
                del socketio_frame.frame_buffers[file_id]

    except Exception as e:
        logger.error(f"处理视频时出错: {str(e)}")

        # 发送错误通知
        socketio_frame.send_error_notification(file_id, {
            'message': f"处理视频时出错: {str(e)}"
        })

        # 清理任务状态
        if file_id in socketio_frame.active_tasks:
            del socketio_frame.active_tasks[file_id]
        if file_id in socketio_frame.frame_buffers:
            del socketio_frame.frame_buffers[file_id]


def process_frame(frame):
    """
    处理单帧图像

    这里应当是您自己实现的视频帧处理逻辑。
    作为占位符，这里仅提供一个简单的示例。

    参数:
    - frame: 输入帧图像

    返回:
    - 处理后的帧
    """
    # 这里是示例，实际处理逻辑由您提供
    # 例如：添加文本水印

    return detect_frame(frame)
