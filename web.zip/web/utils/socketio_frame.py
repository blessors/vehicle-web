import base64

import cv2
from flask import request, jsonify

from web.config.config import Config
from web.config.socket_set import socketio

config = Config()
logger = config.logger

# 存储当前处理任务的信息
active_tasks = {}
video_sockets = {}
frame_buffers = {}


# WebSocket连接
@socketio.on('connect', namespace='/ws/process')
def handle_connect():
    """处理WebSocket连接"""
    logger.info(f"客户端连接: {request.sid}")



@socketio.on('disconnect', namespace='/ws/process')
def handle_disconnect():
    """处理WebSocket断开连接"""
    logger.info(f"客户端断开连接: {request.sid}")
    # 清理任务资源
    for file_id, sid in list(video_sockets.items()):
        if sid == request.sid:
            if file_id in active_tasks:
                active_tasks[file_id]['should_stop'] = True
            if file_id in frame_buffers:
                del frame_buffers[file_id]
            del video_sockets[file_id]
            break


@socketio.on('join', namespace='/ws/process')
def handle_join(data):
    """处理加入特定处理任务的房间"""
    file_id = data.get('file_id')
    if not file_id:
        return

    # 将客户端关联到特定文件的处理
    video_sockets[file_id] = request.sid
    logger.info(f"客户端 {request.sid} 加入了文件 {file_id} 的处理")
    print(f"客户端 {request.sid} 加入了文件 {file_id} 的处理")



def send_progress_update(file_id, data):
    """发送处理进度更新到前端"""
    # print("file_id:", file_id)

    if file_id in video_sockets:
        sid = video_sockets[file_id]
        socketio.emit('process_update', {
            'type': 'progress',
            'file_id': file_id,
            'processed_frames': data['processed_frames'],
            'total_frames': data['total_frames'],
            'progress_percent': data['progress_percent'],
            'estimated_time_remaining': data['estimated_time_remaining']
        }, room=sid, namespace='/ws/process')




def send_processed_frame(file_id, frame):
    """发送处理后的帧到前端"""
    if file_id in video_sockets:
        sid = video_sockets[file_id]

        # 将OpenCV帧转换为JPEG图像
        _, buffer = cv2.imencode('.jpg', frame, [cv2.IMWRITE_JPEG_QUALITY, 80])
        # 转换为base64编码
        jpg_as_text = base64.b64encode(buffer).decode('utf-8')

        # 发送帧数据
        socketio.emit('process_update', {
            'type': 'frame_data',
            'file_id': file_id,
            'frame_data': jpg_as_text
        }, room=sid, namespace='/ws/process')



def send_completion_notification(file_id, data):
    """发送处理完成通知到前端"""
    if file_id in video_sockets:
        sid = video_sockets[file_id]
        socketio.emit('process_update', {
            'type': 'complete',
            'file_id': file_id,
            'video_url': data['video_url'],
            'file_name': data['file_name']
        }, room=sid, namespace='/ws/process')
        print("data['video_url']: ", data['video_url'])



def send_error_notification(file_id, data):
    """发送错误通知到前端"""
    if file_id in video_sockets:
        sid = video_sockets[file_id]
        socketio.emit('process_update', {
            'type': 'error',
            'file_id': file_id,
            'message': data['message']
        }, room=sid, namespace='/ws/process')
