from web.config.config import Config

config = Config()

def upload_to_oss(image_data, file_name):
    """
    将图片上传到阿里云OSS
    :param image_data: 图片的二进制数据
    :param file_name: 存储在OSS上的文件名
    :return: 图片的公开URL
    """
    try:
        # 上传文件到OSS
        result = config.bucket.put_object(file_name, image_data)

        if result.status == 200:
            # 生成公开访问的URL（如果Bucket是公共读的）
            # 如果是私有Bucket，需要生成签名URL
            #url = config.bucket.sign_url('GET', file_name, 3600 * 24 * 365 * 10)  # 10年有效期
            # 或者如果是公共读Bucket可以直接构造URL
            url = f"https://{config.OSS_BUCKET_NAME}.{config.OSS_ENDPOINT.replace('https://', '')}/{file_name}"
            return url
        else:
            raise Exception("OSS upload failed")
    except Exception as e:
        raise e
