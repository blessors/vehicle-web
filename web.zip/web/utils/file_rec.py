import cv2
import numpy as np

from web.processors.Vehicle_rec import web_detect

def res_code(code, data):
    wrapped_code = {
        'code': code,
        'data': data,
    }
    return wrapped_code

def detect(file):
    # if isinstance(file, np.ndarray):
    #     # 处理 frame 类型数据（NumPy 数组）
    #     img = file
    # else :
    # 读取上传的图片数据
    img_bytes = file.read()

    # 将图像转换为numpy数组
    nparr = np.frombuffer(img_bytes, np.uint8)
    img = cv2.imdecode(nparr, cv2.IMREAD_COLOR)

    # 调用YOLOv8检测函数
    annotated_image, proc_time = web_detect(img)

    # 将标注图像转换为jpg二进制数据
    _, buffer = cv2.imencode('.jpg', annotated_image)
    img_bytes = buffer.tobytes()

    return img_bytes, proc_time

def detect_frame(frame):
    # 调用YOLOv8检测函数
    annotated_frame, proc_time = web_detect(frame)

    # # 将标注图像转换为jpg二进制数据
    # _, buffer = cv2.imencode('.jpg', annotated_image)
    # img_bytes = buffer.tobytes()

    return annotated_frame