from datetime import datetime

import torch
import cv2
import numpy as np
import argparse
import copy
import time
import os
from ultralytics.nn.tasks import attempt_load_weights
from plate_recognition.plate_rec import get_plate_result, init_model, cv_imread
from plate_recognition.double_plate_split_merge import get_split_merge
from fonts.cv_puttext import cv2ImgAddText


def allFilePath(rootPath, allFileList):
    """递归获取文件夹内所有文件路径"""
    fileList = os.listdir(rootPath)
    for temp in fileList:
        if os.path.isfile(os.path.join(rootPath, temp)):
            allFileList.append(os.path.join(rootPath, temp))
        else:
            allFilePath(os.path.join(rootPath, temp), allFileList)


# def four_point_transform(image, pts):
#     """透视变换得到车牌小图"""
#     rect = pts.astype('float32')
#     (tl, tr, br, bl) = rect
#     widthA = np.sqrt(((br[0] - bl[0]) ** 2) + ((br[1] - bl[1]) ** 2))
#     widthB = np.sqrt(((tr[0] - tl[0]) ** 2) + ((tr[1] - tl[1]) ** 2))
#     maxWidth = max(int(widthA), int(widthB))
#     heightA = np.sqrt(((tr[0] - br[0]) ** 2) + ((tr[1] - br[1]) ** 2))
#     heightB = np.sqrt(((tl[0] - bl[0]) ** 2) + ((tl[1] - bl[1]) ** 2))
#     maxHeight = max(int(heightA), int(heightB))
#     dst = np.array([
#         [0, 0],
#         [maxWidth - 1, 0],
#         [maxWidth - 1, maxHeight - 1],
#         [0, maxHeight - 1]], dtype="float32")
#     M = cv2.getPerspectiveTransform(rect, dst)
#     warped = cv2.warpPerspective(image, M, (maxWidth, maxHeight))
#     return warped


def letter_box(img, size=(640, 640)):
    """YOLO前处理 letter_box操作"""
    h, w, _ = img.shape
    r = min(size[0] / h, size[1] / w)
    new_h, new_w = int(h * r), int(w * r)
    new_img = cv2.resize(img, (new_w, new_h))
    left = int((size[1] - new_w) / 2)
    top = int((size[0] - new_h) / 2)
    right = size[1] - left - new_w
    bottom = size[0] - top - new_h
    img = cv2.copyMakeBorder(new_img, top, bottom, left, right, cv2.BORDER_CONSTANT, value=(114, 114, 114))
    return img, r, left, top


def load_model(weights, device):
    """加载YOLO模型"""
    model = attempt_load_weights(weights, device=device)
    return model


def xywh2xyxy(det):
    """xywh转化为xyxy"""
    y = det.clone()
    y[:, 0] = det[:, 0] - det[0:, 2] / 2
    y[:, 1] = det[:, 1] - det[0:, 3] / 2
    y[:, 2] = det[:, 0] + det[0:, 2] / 2
    y[:, 3] = det[:, 1] + det[0:, 3] / 2
    return y


def my_nms(dets, iou_thresh):
    """NMS操作"""
    y = dets.clone()
    y_box_score = y[:, :5]
    index = torch.argsort(y_box_score[:, -1], descending=True)
    keep = []
    while index.size()[0] > 0:
        i = index[0].item()
        keep.append(i)
        x1 = torch.maximum(y_box_score[i, 0], y_box_score[index[1:], 0])
        y1 = torch.maximum(y_box_score[i, 1], y_box_score[index[1:], 1])
        x2 = torch.minimum(y_box_score[i, 2], y_box_score[index[1:], 2])
        y2 = torch.minimum(y_box_score[i, 3], y_box_score[index[1:], 3])
        zero_ = torch.tensor(0).to(y.device)
        w = torch.maximum(zero_, x2 - x1)
        h = torch.maximum(zero_, y2 - y1)
        inter_area = w * h
        nuion_area1 = (y_box_score[i, 2] - y_box_score[i, 0]) * (y_box_score[i, 3] - y_box_score[i, 1])
        union_area2 = (y_box_score[index[1:], 2] - y_box_score[index[1:], 0]) * (
                    y_box_score[index[1:], 3] - y_box_score[index[1:], 1])

        iou = inter_area / (nuion_area1 + union_area2 - inter_area)
        idx = torch.where(iou <= iou_thresh)[0]
        index = index[idx + 1]
    return keep


def restore_box(dets, r, left, top):
    """坐标还原到原图上"""
    dets[:, [0, 2]] = dets[:, [0, 2]] - left
    dets[:, [1, 3]] = dets[:, [1, 3]] - top
    dets[:, :4] /= r
    return dets


def post_processing(prediction, conf, iou_thresh, r, left, top):
    """后处理"""
    prediction = prediction.permute(0, 2, 1).squeeze(0)
    xc = prediction[:, 4:].amax(1) > conf  # 过滤掉小于conf的框
    x = prediction[xc]
    if not len(x):
        return []
    boxes = x[:, :4]  # 框
    boxes = xywh2xyxy(boxes)  # 中心点 宽高 变为 左上 右下两个点
    score, index = torch.max(x[:, 4:], dim=-1, keepdim=True)  # 找出得分和所属类别
    x = torch.cat((boxes, score, index), dim=1)  # 重新组合

    keep = my_nms(x, iou_thresh)
    x = x[keep]
    x = restore_box(x, r, left, top)
    return x


def pre_processing(img, img_size, device):
    """前处理"""
    #cv2.imshow('Processed Image', img)
    img, r, left, top = letter_box(img, (img_size, img_size))
    img = img[:, :, ::-1].transpose((2, 0, 1)).copy()  # bgr2rgb hwc2chw
    img = torch.from_numpy(img).to(device)
    img = img.float()
    img = img / 255.0
    img = img.unsqueeze(0)
    return img, r, left, top


def detect_vehicle(img, img_ori, vehicle_model, img_size, device):
    """检测车辆并返回结果"""
    result_list = []
    img, r, left, top = pre_processing(img, img_size, device)
    predict = vehicle_model(img)[0]
    outputs = post_processing(predict, 0.3, 0.5, r, left, top)

    #print("Vehicle_outputs: " + outputs)
    for output in outputs:
        result_dict = {}
        output = output.squeeze().cpu().numpy().tolist()
        #print(output)
        rect = output[:4]
        rect = [int(x) for x in rect]
        #print(rect)
        label = int(output[-1])
        confidence = output[4]

        # 确保坐标在图像范围内
        rect[0] = max(0, rect[0])
        rect[1] = max(0, rect[1])
        rect[2] = min(img_ori.shape[1], rect[2])
        rect[3] = min(img_ori.shape[0], rect[3])

        # 截取车辆区域
        roi_img = img_ori[rect[1]:rect[3], rect[0]:rect[2]]

        result_dict['rect'] = rect
        result_dict['label'] = label
        result_dict['confidence'] = confidence
        result_dict['roi_img'] = roi_img
        result_list.append(result_dict)

    return result_list


def recognize_plate(plate_roi, plate_rec_model, device, is_double_layer=False):
    """识别车牌内容"""
    if plate_roi.size == 0 or max(plate_roi.shape) == 0:
        return "", 0, "", 0

    # 如果是双层车牌，进行分割后拼接处理
    if is_double_layer:
        plate_roi = get_split_merge(plate_roi)

    # 使用车牌识别模型识别字符和颜色
    plate_number, rec_prob, plate_color, color_conf = get_plate_result(plate_roi, device, plate_rec_model,
                                                                       is_color=True)

    return plate_number, rec_prob, plate_color, color_conf


def integrated_detection_recognition(img, vehicle_model, plate_rec_model,
                                     img_size, device):
    """整合检测与识别流程"""
    # 读取图像
    if img is None:
        print(f"Failed to read image ?")
        return [], img

    img_ori = copy.deepcopy(img)

    # 步骤1: 检测车辆
    vehicle_results = detect_vehicle(img, img_ori, vehicle_model, img_size, device)

    #print(vehicle_results)

    results = []

    plate_info_list = [vehicle_result for vehicle_result in vehicle_results if
                       vehicle_result['label'] == 6 or vehicle_result['label'] == 7]
    plate_results = []

        # 步骤4: 识别每个检测到的车牌
    for plate_info in plate_info_list:
        plate_roi = plate_info['roi_img']
        is_double_layer = (plate_info['label'] == 7)

        # 识别车牌号码和颜色
        plate_number, rec_prob, plate_color, color_conf = recognize_plate(
            plate_roi, plate_rec_model, device, is_double_layer
        )

        plate_info_tmp = {
            'plate_number': plate_number,
            'plate_color': plate_color,
            'plate_rect': plate_info['rect'],  # 相对于车辆ROI的坐标
            'rec_confidence': rec_prob,
            'color_confidence': color_conf,
            'plate_confidence': plate_info['confidence'],
            'is_double_layer': is_double_layer,
            'label': plate_info['label']
        }

        plate_results.append(plate_info_tmp)

    # 整合车辆和车牌信息
    vehicle_results = [ vehicle_result for vehicle_result in vehicle_results if vehicle_result['label'] != 6 and vehicle_result['label'] != 7]
    integrated_vehicle_results, integrated_plate_results = convert_to_chinese_info(vehicle_results, plate_results)
    #print(integrated_results)
    return integrated_vehicle_results, integrated_plate_results, img_ori


def convert_to_chinese_info(vehicle_results, plate_results):
    # 定义分类标签到中文信息的映射
    vehicle_type_mapping = {
        '0': '公交车',
        '1': '微型客车',
        '2': '小型厢式车',
        '3': '轿车',
        '4': 'SUV',
        '5': '卡车',
        '6': 'Single',
        '7': 'Double',
        '8': 'Unknown'
    }

    new_vehicle_results = []
    new_plate_results = []
    for vehicle_result in vehicle_results:
        # 转换车辆类型信息
        vehicle_type = str(vehicle_result['label'])
        #print("vehicle_type: " + str(vehicle_typ))
        chinese_vehicle_type = vehicle_type_mapping.get(vehicle_type, vehicle_type)
        #print("chinese_vehicle_type: " + str(chinese_vehicle_type))
        vehicle_result_tmp = {
            'vehicle_rect': vehicle_result['rect'],
            'vehicle_label': chinese_vehicle_type,
            'vehicle_confidence': vehicle_result['confidence']
        }
        new_vehicle_results.append(vehicle_result_tmp)
    for plate_result in plate_results:
        # 转换车辆类型信息
        plate_type = str(plate_result['label'])
        #print("vehicle_type: " + str(vehicle_typ))
        chinese_plate_type = vehicle_type_mapping.get(plate_type, plate_type)
        #print("chinese_vehicle_type: " + str(chinese_vehicle_type))
        plate_result_tmp = {
            'plate_number': plate_result['plate_number'],
            'plate_color': plate_result['plate_color'],
            'plate_rect': plate_result['plate_rect'],
            'plate_label': chinese_plate_type,
            'rec_confidence': plate_result['rec_confidence'],
            'color_confidence': plate_result['color_confidence'],
            'plate_confidence': plate_result['plate_confidence'],
            'is_double_layer': plate_result['is_double_layer'],

        }
        new_plate_results.append(plate_result_tmp)

    return new_vehicle_results, new_plate_results


def draw_result(img, vehicle_results, plate_results):
    """在图像上绘制识别结果"""
    result_str = ""

    for vehicle_result in vehicle_results:
        # 绘制车辆框
        vehicle_rect = vehicle_result['vehicle_rect']
        cv2.rectangle(img, (vehicle_rect[0], vehicle_rect[1]),
                      (vehicle_rect[2], vehicle_rect[3]), (0, 255, 0), 2)

        # 显示车辆信息
        vehicle_infom = f"{vehicle_result['vehicle_label']} {vehicle_result['vehicle_confidence']}"
        # cv2.putText(img, vehicle_infom, (vehicle_rect[0], vehicle_rect[1] + 20),
        #             cv2.FONT_HERSHEY_SIMPLEX, 0.75, (0, 255, 0), 2)
        img = cv2ImgAddText(img, vehicle_infom, vehicle_rect[0], vehicle_rect[1] + 10,
                     (0, 255, 0), 21)

    # 处理每个车牌
    for plate_result in plate_results:
        # 获取车牌在原图上的绝对位置
        plate_rect = plate_result['plate_rect']
        # 绘制车牌框
        cv2.rectangle(img, (plate_rect[0], plate_rect[1]),
                        (plate_rect[2], plate_rect[3]), (0, 0, 255), 2)


        # 显示车牌信息
        #plate_type = "双层" if plate_result['is_double_layer'] else "单层"
        #plate_info = f"{plate['plate_number']} {plate['rec_confidence']} {plate['plate_color']} {plate['color_confidence']}"
        plate_info = f"{plate_result['plate_number']}  {plate_result['plate_color']} {plate_result['color_confidence']}"
        #print("rec_confidence: " + f"{plate['rec_confidence']}"                                                                                                                            )

        # 使用中文显示
        img = cv2ImgAddText(img, plate_info, plate_rect[0],
                            plate_rect[1] - 30, (0, 255, 0), 21)

        result_str += plate_info + " "

    print(result_str)
    return img


def web_detect(img):

    parser = argparse.ArgumentParser()
    parser.add_argument('--vehicle_model', type=str, default='models/best.pt', help='vehicle detection model')
    parser.add_argument('--plate_rec_model', type=str, default='models/plate_rec_color.pt',
                        help='license plate recognition model')
    parser.add_argument('--img_size', type=int, default=640, help='inference size (pixels)')
    parser.add_argument('--output', type=str, default='result', help='output directory')
    parser.add_argument('--detailed_viz', action='store_true', help='generate detailed visualization for each stage')

    opt = parser.parse_args()

    # 默认启用详细可视化
    opt.detailed_viz = True

    # 创建输出目录
    save_path = opt.output
    if not os.path.exists(save_path):
        os.makedirs(save_path)

    # 设置设备
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")

    # 加载模型
    print("Loading models...")
    vehicle_model = load_model(opt.vehicle_model, device)
    plate_rec_model = init_model(device, opt.plate_rec_model, is_color=True)

    # 模型设置为评估模式
    vehicle_model.eval()
    plate_rec_model.eval()

    # 计算模型参数量
    total_vehicle = sum(p.numel() for p in vehicle_model.parameters())
    total_plate_rec = sum(p.numel() for p in plate_rec_model.parameters())

    print(f"Vehicle model params: {total_vehicle / 1e6:.2f}M")
    print(f"Plate recognition model params: {total_plate_rec / 1e6:.2f}M")

    # 处理所有图片
    total_time = 0
    count = 0
    start_time = time.time()

    print(f"Processing ", end=" ")

    img_time_start = time.time()

    # 执行检测和识别
    vehicle_results, plate_results, img_processed = integrated_detection_recognition(
        img, vehicle_model, plate_rec_model,opt.img_size, device
    )

    # 绘制结果
    if len(vehicle_results) > 0 or len(plate_results) > 0:
        img_processed = draw_result(img_processed, vehicle_results, plate_results)

    # 如果需要详细可视化，生成四阶段结果

    # viz_result_dir = visualize_detection_stages(pic_path, results, img_processed, save_path)
    # print(f"Detailed visualization saved to: {viz_result_dir}")

    img_time_end = time.time()
    proc_time = img_time_end - img_time_start

    # 只计算第一张后的处理时间（第一张通常包含模型加载时间）
    if count > 0:
            total_time += proc_time

    # 保存结果图片
    # 获取当前日期和时间
    now = datetime.now()
    # 定义日期格式
    date_time = now.strftime("%Y%m%d_%H%M%S")
    # 获取图片扩展名
    #_, file_extension = os.path.splitext(pic_path)
    # 生成新的文件名
    img_name = f"{date_time}.jpg"
    save_img_path = os.path.join(save_path, img_name)
    cv2.imwrite(save_img_path, img_processed)

    print(f"Processing time: {proc_time:.4f}s")
    count += 1

    # 输出总体统计信息
    if count > 1:
        avg_time = total_time / (count - 1)
        print(f"Total time: {time.time() - start_time:.2f}s, Average time per image: {avg_time:.4f}s")

    return img_processed, proc_time


if __name__ == "__main__":
    image = cv2.imread("./vehicle_0000010.jpg")
    web_detect(image)